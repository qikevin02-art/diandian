//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CB3LOab-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DNUybgCU.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DNUybgCU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cri_bWm_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
